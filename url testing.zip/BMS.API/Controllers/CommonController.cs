﻿using BMS.Data.Entities;
using BMS.Services.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace BMS.API.Controllers
{
    public class CommonController : BaseApiController
    {
        private readonly ICommonService _commonService;

        public CommonController(ICommonService commonService)
        {
            _commonService = commonService;

        }
        [HttpGet]
        public List<StateMaster> GetStates()
        {
            var states = _commonService.GetStates();
            return states;
        }
        [HttpGet]
        public List<CityMaster> GetCities(int stateId)
        {
            var cities = _commonService.GetCities(stateId);
            return cities;
        }
        [HttpGet]
        public List<ClassMaster> GetClasses()
        {
            var classes = _commonService.GetClasses();
            return classes;
        }

    }
}
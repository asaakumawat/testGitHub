﻿using BMS.API.JWT;
using BMS.Services.Users;
using BMS.ViewModels.User;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace BMS.API.Controllers
{
    public class AccountController : BaseApiController
    {
        private readonly IUserService _userService;

        public AccountController(IUserService userService)
        {
            _userService = userService;

        }

        [HttpPost]
        [AllowAnonymous]
        public UserLoginResponseModel Login(UserLoginVM userModel)
        {
            UserLoginResponseModel loginResponseModel = new UserLoginResponseModel();
            string errorMessage = string.Empty;
            if (userModel.UserName != string.Empty && userModel.Password != string.Empty)
            {
                JWTManager jWTManager = new JWTManager();
                loginResponseModel.AccessToken = jWTManager.GenerateTokenForUser(userModel.UserName, false);
                loginResponseModel.RefreshToken = jWTManager.GenerateTokenForUser(userModel.UserName, true);
            }
            return loginResponseModel;
        }

        [HttpPost]
        public UserLoginResponseModel GetNewToken(UserLoginVM userModel)
        {
            JWTManager jWTManager = new JWTManager();
            UserLoginResponseModel loginResponseModel = new UserLoginResponseModel();
            loginResponseModel.AccessToken = jWTManager.GenerateTokenForUser(userModel.UserName, false);
            loginResponseModel.RefreshToken = jWTManager.GenerateTokenForUser(userModel.UserName, true);
            return loginResponseModel;
        }
    }
}

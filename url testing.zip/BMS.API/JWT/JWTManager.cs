﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Security.Claims;
using System.Web;
using System.IdentityModel.Tokens.Jwt;
using Microsoft.IdentityModel.Tokens;
using System.Text;
using BMS.Common;

namespace BMS.API.JWT
{
    public class JWTManager
    {
        SecurityKey signingKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(AppConstants.JWTKey));
        public string GenerateTokenForUser(string userName, bool isRefreshToken)
        {
            var signingKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(AppConstants.JWTKey));
            var now = DateTime.UtcNow;
            var signingCredentials = new SigningCredentials(signingKey,
               SecurityAlgorithms.HmacSha256Signature, SecurityAlgorithms.Sha256Digest);

            var claims = GenerateClaims();
            claims.Add(new Claim(ClaimTypes.Name, userName));
            var claimsIdentity = new ClaimsIdentity(claims, "Custom");

            var securityTokenDescriptor = new SecurityTokenDescriptor()
            {
                Subject = claimsIdentity,
                SigningCredentials = signingCredentials,
                NotBefore = now,
                Expires = now.Add(TimeSpan.FromMinutes(AppConstants.JWTTokenTimeoutMinutes * (isRefreshToken ? 2 : 1)))
            };
            var tokenHandler = new JwtSecurityTokenHandler();
            var plainToken = tokenHandler.CreateToken(securityTokenDescriptor);
            var signedAndEncodedToken = tokenHandler.WriteToken(plainToken);
            return signedAndEncodedToken;
        }

        public JwtSecurityToken GenerateUserClaimFromJWT(string authToken)
        {
            var tokenValidationParameters = new TokenValidationParameters()
            {
                ValidateAudience = false,
                ValidateIssuer = false,
                IssuerSigningKey = signingKey,
                ValidateLifetime = true,
                LifetimeValidator = LifetimeValidator,
            };
            var tokenHandler = new JwtSecurityTokenHandler();
            SecurityToken validatedToken;
            try
            {
                tokenHandler.ValidateToken(authToken, tokenValidationParameters, out validatedToken);
            }
            catch (Exception ex)
            {
                return null;
            }
            return validatedToken as JwtSecurityToken;
        }

        private bool LifetimeValidator(DateTime? notBefore, DateTime? expires, SecurityToken token, TokenValidationParameters @params)
        {
            if (expires != null)
            {
                return expires > DateTime.UtcNow;
            }
            return false;
        }

        public JWTAuthenticationIdentity PopulateUserIdentity(JwtSecurityToken userPayloadToken)
        {
            string name = ((userPayloadToken)).Claims.FirstOrDefault(m => m.Type == "unique_name").Value;
            ExtractClaims(userPayloadToken);
            return new JWTAuthenticationIdentity(name) { UserName = name };

        }

        private List<Claim> GenerateClaims()
        {
            List<Claim> claims = new List<Claim>();
            //claims.Add(new Claim("CustomerId", Convert.ToString(SessionManager.CustomerId)));
            //claims.Add(new Claim("HidePrice", Convert.ToString(SessionManager.HidePrice)));
            //claims.Add(new Claim("IsDemoUser", Convert.ToString(SessionManager.IsDemoUser)));
            //claims.Add(new Claim("IsStopCustomer", Convert.ToString(SessionManager.IsStopCustomer)));
            //claims.Add(new Claim("CustomerRole", Convert.ToString(SessionManager.CustomerRole)));
            //claims.Add(new Claim("CustomerRoleGroupId", Convert.ToString(SessionManager.CustomerRoleGroupId)));
            //claims.Add(new Claim("CustomerWelcomeName", Convert.ToString(SessionManager.CustomerWelcomeName)));
            //claims.Add(new Claim("CustomerLogoPath", Convert.ToString(SessionManager.CustomerLogoPath)));
            //claims.Add(new Claim("CustomerPaymentMode", Convert.ToString(SessionManager.CustomerPaymentMode)));
            //claims.Add(new Claim("FranchiseOrResellerId", Convert.ToString(SessionManager.FranchiseOrResellerId)));
            //claims.Add(new Claim("WarrantyEnabled", Convert.ToString(SessionManager.WarrantyEnabled)));
            //claims.Add(new Claim("AdminAcessorialGroupId", Convert.ToString(SessionManager.AdminAcessorialGroupId)));
            //claims.Add(new Claim("CustomerAcessorialGroupId", Convert.ToString(SessionManager.CustomerAcessorialGroupId)));
            //claims.Add(new Claim("CustomerRefrence", Convert.ToString(SessionManager.CustomerRefrence)));
            //claims.Add(new Claim("IsTicketingAllowed", Convert.ToString(SessionManager.IsTicketingAllowed)));
            return claims;
        }

        private void ExtractClaims(JwtSecurityToken userPayloadToken)
        {
            IEnumerable<Claim> claims = ((userPayloadToken)).Claims;
            //SessionManager.CustomerId = Convert.ToInt32(claims.FirstOrDefault(m => m.Type == "CustomerId").Value);
            //SessionManager.HidePrice = Convert.ToBoolean(claims.FirstOrDefault(m => m.Type == "HidePrice").Value);
            //SessionManager.IsDemoUser = Convert.ToBoolean(claims.FirstOrDefault(m => m.Type == "IsDemoUser").Value);
            //SessionManager.IsStopCustomer = Convert.ToBoolean(claims.FirstOrDefault(m => m.Type == "IsStopCustomer").Value);
            //SessionManager.CustomerRole = Convert.ToInt16(claims.FirstOrDefault(m => m.Type == "CustomerRole").Value);
            //SessionManager.CustomerRoleGroupId = Convert.ToInt32(claims.FirstOrDefault(m => m.Type == "CustomerRoleGroupId").Value);
            //SessionManager.CustomerWelcomeName = Convert.ToString(claims.FirstOrDefault(m => m.Type == "CustomerWelcomeName").Value);
            //SessionManager.CustomerLogoPath = Convert.ToString(claims.FirstOrDefault(m => m.Type == "CustomerLogoPath").Value);
            //SessionManager.CustomerPaymentMode = Convert.ToInt32(claims.FirstOrDefault(m => m.Type == "CustomerPaymentMode").Value);
            //SessionManager.FranchiseOrResellerId = Convert.ToInt32(claims.FirstOrDefault(m => m.Type == "FranchiseOrResellerId").Value);
            //SessionManager.WarrantyEnabled = Convert.ToBoolean(claims.FirstOrDefault(m => m.Type == "WarrantyEnabled").Value);
            //SessionManager.AdminAcessorialGroupId = Convert.ToInt32(claims.FirstOrDefault(m => m.Type == "AdminAcessorialGroupId").Value);
            //SessionManager.CustomerAcessorialGroupId = Convert.ToInt32(claims.FirstOrDefault(m => m.Type == "CustomerAcessorialGroupId").Value);
            //SessionManager.CustomerRefrence = Convert.ToString(claims.FirstOrDefault(m => m.Type == "CustomerRefrence").Value);
            //SessionManager.IsTicketingAllowed = Convert.ToBoolean(claims.FirstOrDefault(m => m.Type == "IsTicketingAllowed").Value);
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BMS.Data;
using BMS.Data.Entities;

namespace BMS.Services.Common
{
    public class CommonService : ICommonService
    {
        BMSContext bMSContext = new BMSContext();
        public List<StateMaster> GetStates()
        {
            return bMSContext.StateMaster.ToList();
        }
        public List<CityMaster> GetCities(int stateId)
        {
            return bMSContext.CityMaster.Where(a => stateId == 0 || a.StateId == stateId).ToList();
        }
        public List<ClassMaster> GetClasses()
        {
            return bMSContext.ClassMaster.ToList();
        }
        public List<SessionMaster> GetSessions()
        {
            return bMSContext.SessionMaster.ToList();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BMS.Data;
using BMS.Data.Entities;

namespace BMS.Services.Users
{
    public class UserService : IUserService
    {
        BMSContext bMSContext = new BMSContext();

        public List<User> GetUsers()
        {
            return bMSContext.Users.ToList();
        }
    }
}

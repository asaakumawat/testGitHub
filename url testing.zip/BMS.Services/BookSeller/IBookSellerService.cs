﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BMS.Data.Entities;
using BMS.ViewModels.User;

namespace BMS.Services.BookSeller
{
    public interface IBookSellerService
    {
        BookSellerMaster GetBookSellerById(int id);
        BookSellerMaster SaveBookSeller(BookSellerVM model);
        List<BookSellerVM> GetBookSellers();
    }
}

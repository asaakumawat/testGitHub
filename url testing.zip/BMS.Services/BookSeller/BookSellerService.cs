﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BMS.Data;
using BMS.Data.Entities;
using BMS.ViewModels.User;

namespace BMS.Services.BookSeller
{
    public class BookSellerService : IBookSellerService
    {
        BMSContext bMSContext = new BMSContext();
        public BookSellerMaster GetBookSellerById(int id)
        {
            return bMSContext.BookSellerMaster.Where(m => m.BSM_Id == id).FirstOrDefault();
        }
        public BookSellerMaster SaveBookSeller(BookSellerVM model)
        {
            var entity = GetBookSellerById(model.Id);
            if (entity != null)
            {
                entity.BSM_FirstName = model.FirstName;
                entity.BSM_LastName = model.LastName;
                entity.BSM_FirmName = model.FirmName;
                entity.BSM_RegistrationNo = model.RegistrationNo;
                entity.BSM_Address1 = model.Address1;
                entity.BSM_Address2 = model.Address2;
                entity.BSM_CityId = model.CityId;
                entity.BSM_StateId = model.StateId;
                entity.BSM_PostCode = model.PostCode;
                entity.BSM_MobileNo = model.MobileNo;
                entity.BSM_EmailId = model.EmailId;
                entity.BSM_Active = model.Active;
                entity.BSM_EditedDate = DateTime.Now;
                entity.BSM_EditedBy = model.EditedBy;
                bMSContext.SaveChanges();
            }
            else
            {
                entity = new BookSellerMaster();
                entity.BSM_FirstName = model.FirstName;
                entity.BSM_LastName = model.LastName;
                entity.BSM_FirmName = model.FirmName;
                entity.BSM_RegistrationNo = model.RegistrationNo;
                entity.BSM_Address1 = model.Address1;
                entity.BSM_Address2 = model.Address2;
                entity.BSM_CityId = model.CityId;
                entity.BSM_StateId = model.StateId;
                entity.BSM_PostCode = model.PostCode;
                entity.BSM_MobileNo = model.MobileNo;
                entity.BSM_EmailId = model.EmailId;
                entity.BSM_Active = model.Active;
                entity.BSM_CreationDate = DateTime.Now;
                entity.BSM_CreatedBy = model.CreatedBy;
                bMSContext.BookSellerMaster.Add(entity);
                bMSContext.SaveChanges();
            }
            return entity;
        }
        public List<BookSellerVM> GetBookSellers()
        {
            var bookSellers = (from BSM in bMSContext.BookSellerMaster
                               join S in bMSContext.StateMaster on BSM.BSM_StateId equals S.StateId
                               join C in bMSContext.CityMaster on BSM.BSM_CityId equals C.CityId
                               orderby BSM.BSM_Id
                               select new BookSellerVM()
                               {
                                   Id = BSM.BSM_Id,
                                   FirstName = BSM.BSM_FirstName,
                                   LastName = BSM.BSM_LastName,
                                   FirmName = BSM.BSM_FirmName,
                                   RegistrationNo = BSM.BSM_RegistrationNo,
                                   Address1 = BSM.BSM_Address1,
                                   Address2 = BSM.BSM_Address2,
                                   CityId = BSM.BSM_CityId,
                                   StateId = BSM.BSM_StateId,
                                   PostCode = BSM.BSM_PostCode,
                                   MobileNo = BSM.BSM_MobileNo,
                                   EmailId = BSM.BSM_EmailId,
                                   Active = BSM.BSM_Active,
                                   CreationDate = BSM.BSM_CreationDate,
                                   CreatedBy = BSM.BSM_CreatedBy,
                                   EditedBy = BSM.BSM_EditedBy,
                                   EditedDate = BSM.BSM_EditedDate,
                                   StateName = S.StateName,
                                   CityName = C.CityName,
                               }).ToList();
            return bookSellers;

        }

    }
}

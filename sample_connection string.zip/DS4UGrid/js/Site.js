﻿
//on document ready
function documentReady(root) {
    layPage();

    handleAnchors();
    
    $(document).on('ds4uload', 'table.ds4u-ajaxlist', wrapLists);

    $(window).on('resize', layPage);

    $('#btnLogo').click(function (e) {
        if ($(window).width() < 1050) {
            e.preventDefault();
            $('#btnMenuToggle').click();
        }
    });
    
    $('#btnMenuToggle').click(function () {
        MenuToggle($('#demoMenu').is(':visible'), 1);
    });

    $('pre').addClass('prettyprint');

    //show code 
    $('.code').hide().before('<br/>').before($('<span class="shcode">show code</span>').click(function () {
        var btn = $(this);
        btn.toggleClass("hideCode showCode");

        if (btn.hasClass("hideCode")) {
            btn.html("hide code");
            $(this).next().fadeIn();
        } else {
            btn.html("show code");
            $(this).next().fadeOut();
        }
    }));

    //tabs 
    $('.tabs').each(function (i, item) {
        var $tabstrip = $(item);
        var $tabs = $tabstrip.children();
        $tabs.wrapAll('<div class="tabscontent"/>');
        var $bar = $('<div class="tabsbar"></div>');
        $tabstrip.prepend($bar);
        $tabs.each(function (ti, tab) {
            var $tab = $(tab);
            var btnclass = "tab-btn";

            if (ti)
                $tab.hide();
            else
                btnclass += " active";

            var $btn = $('<button type="button" class="' + btnclass + '">' + $tab.data('caption') + '</button>');
            $btn.click(function () {
                $bar.children().removeClass('active');
                $btn.addClass('active');
                $tabs.hide();
                $tab.show();
            });
            $bar.append($btn);
        });
    });

    //change popup
    $('#chPopupMod').change(function () {
        var p = $('#chPopupMod').val();
        var theme = $('#chTheme').val();
        
        popupMod = p;

        $('.ds4u-popup').each(function () {
            if ($(this).data('api'))
                $(this).data('api').close();
        });

        $('.ds4u-multilookup, .ds4u-lookup').each(function () { $(this).data('api').initPopup(); });

        $.post(root + "Settings/Change", { theme: theme, popupMod: p });
    });

    $('#chTheme').change(function () {
        var newmod = $('#chPopupMod').val();
        var theme = $('#chTheme').val();
        
        $('#ds4uStyle').attr('href', root + "Content/themes/" + theme + "/DS4UGrid.css?v=72");
        $('#modsStyle').attr('href', root + "Content/themes/" + theme + "/mods.css?v=72");
        $.post(root + "Settings/Change", { theme: theme, popupMod: newmod }, function () {
            setTimeout(function () {
                $('.ds4u-grid').each(
                    function () {
                        $(this).data('api').lay();
                    });
            }, 500);
        });
    });
}

function handleAnchors() {
    var anchor = location.hash.replace('#', '').replace(/\(|\)|:|\.|\;|\\|\/|\?|,/g, '');
    $('h3,h2').each(function (_, e) {
        var $e = $(e);
        var name = $e.data('name');
        if (!name) name = $e.html().trim().replace(/ /g, '-').replace(/\(|\)|:|\.|\;|\\|\/|\?|,/g, '');
        name = name.replace('&lt', '').replace('&gt', '');
        $e.append("<a class='anchor' name='" + name + "' href='#" + name + "'>&nbsp;<i class='glyphicon glyphicon-link'></i></a>");
        if (name == anchor) {
            $e.addClass("ds4u-changing").removeClass('ds4u-changing', 3000);
        }
    });
}

var lastw = 0;

function layPage() {
    var ww = $(window).width();

    $("#main").css("min-height", ($(window).height() - 120) + "px");

    if (lastw != ww)
        MenuToggle(ww < 1050);
    lastw = ww;
}

//wrap ajaxlists for horizontal scrolling on small screens
function wrapLists() {
    $('table.ds4u-ajaxlist:not([wrapped])').each(function () {
        var columns = $(this).find('thead th').length;
        var mw = $(this).data('mw');
        if (columns || mw) {
            mw = mw || columns * 120;

            $(this).wrap('<div style="width:100%; overflow:auto;"></div>')
                .wrap('<div style="min-width:' + mw + 'px;padding-bottom:2px;"></div>')
                .attr('wrapped', 'wrapped');
        }
    });
}

function MenuToggle(hide, keepButton) {
    if (hide) {
        $('#demoMenu').hide();
        $('#demoPage').css('margin-left', "0");
        $('#btnMenuToggle').show().removeClass('on');
    } else {
        $('#demoMenu').show();
        $('#demoPage').css('margin-left', "14.5em");
        $('#btnMenuToggle').addClass('on');
        //if (!keepButton) $('#btnMenuToggle').hide();
    }
}

/*begin*/
ds4u.err = function (o, xhr, textStatus, errorThrown) {
    var msg = "unexpected error occured";
    if (xhr) {
        msg = xhr.responseText;
    }
    var btnHide = $('<button type="button" class="ds4u-btn"> hide </button>').click(function () {
        $(this).parent().remove();
    });

    var c = $('<div/>').html(msg).append(btnHide);

    //decide where to attach the inline popup
    if (o.p && o.p.isOpen) { // if helper has popup and is open
        o.p.d.prepend(c); // put msg inside popup div
    } else if (o.f) {
        o.f.html(c); // put msg inside control field
    } else $('body').prepend(c);
};/*end*/

/*beginpopup*/
//this code uses popupMod variable specific to this demo, you shouldn't need this, 
//use utils.setPopup to be able to use the DropdownPopup and Inline (already called in utils.init)
function setds4udemoPopup() {
    var jqueryUIpopup = ds4u.popup;
    ds4u.popup = function (o) {
        if (o.tag && o.tag.DropdownPopup) {
            return ds4um.dropdownPopup(o);
        } else if (o.tag && o.tag.Inline) {
            return ds4um.inlinePopup(o);
        } else if (popupMod == 'inline') {
            return ds4um.inlinePopup(o);
        } else if (popupMod == 'bootstrap') {
            return ds4um.bootstrapPopup(o);
        } else {
            return jqueryUIpopup(o);
        }
    };
}
/*endpopup*/

(function () {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
})();